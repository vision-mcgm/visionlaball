
float trap_pow(float, float);
int fac(int);
int comb(int, int);
CPBCOLOUR *SetRGBfromAngle(double);
int AllocImage(IMAGE *, unsigned int, unsigned int , unsigned int);
void CPBCopyImage(double *, IMAGE);
int getsize(unsigned int *, unsigned int *)